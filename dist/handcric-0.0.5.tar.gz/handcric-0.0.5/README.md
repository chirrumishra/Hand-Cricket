# HANDCRIC

This is a library which hosts a game of Hand Cricket which you can
enjoy while doing your work

Developed by Chiranjeev Mishra

## Example of How to use it 

```python
import handcric
//create an object of class match and here you go
a = handcric.match()
#Now you can play the game
```

Open for pull requests 
check out : https://github.com/chirrumishra/Hand-Cricket
